import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onlinelink',
  templateUrl: './onlinelink.component.html',
  styleUrls: ['./onlinelink.component.css']
})
export class OnlinelinkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
