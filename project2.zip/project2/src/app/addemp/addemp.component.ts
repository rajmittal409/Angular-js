import { Component, OnInit } from '@angular/core';
import { Service1Service, dept} from '../service1.service';
import {FormControl,FormGroup,FormsModule} from '@angular/forms';
@Component({
  selector: 'app-addemp',
  templateUrl: './addemp.component.html',
  styleUrls: ['./addemp.component.css']
})
export class AddempComponent implements OnInit {
 emps:dept[]=[];
 dep:FormGroup;
  service:Service1Service;
  dp1:dept;
  constructor(service:Service1Service){
    this.service=service;
  }
  ngOnInit() {
  this.dep=new FormGroup({depName:new FormControl(),depId:new FormControl});
  }
  onSubmit():void{
    console.log(this.dep.value);
    console.log(this.dep.controls.depName.value);
    alert(this.dep.get("depName").value);}
  
 /* add():void{
    
    this.service.add(this.dep.controls.depId.value,this.dep.get("depName").value);
    this.emps=this.service.getEmployees();
    alert(this.dep.get("depName").value + " added");
    
  }*/
  add2(dp:any):void{
    this.dp1=new dept(dp.t1,dp.t2);
    this.service.add1(this.dp1);
    this.emps=this.service.getEmployees();
    console.log(dp.t1);
    console.log(dp.t2);
   
  }
}
