import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Service1Service } from './service1.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddempComponent } from './addemp/addemp.component';
import { DisplayempComponent } from './displayemp/displayemp.component';
import {HttpClient,HttpClientModule} from '@angular/common/Http';
import { OnlinelinkComponent } from './onlinelink/onlinelink.component';
import { SortPipe } from './sort.pipe';

import {FormsModule} from '@angular/forms'
import{ReactiveFormsModule} from '@angular/forms'
import { OrderBy } from './orderby';
@NgModule({
  declarations: [
    AppComponent,
    AddempComponent,
    DisplayempComponent,
    OnlinelinkComponent,
    SortPipe,
  OrderBy
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [HttpClient,Service1Service],
  bootstrap: [AppComponent]
})
export class AppModule { }
