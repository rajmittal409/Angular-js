export class Employee{
    empNo:Number;
    empName: string;
    ph:Number[];
    constructor(name:string,no:number,ph:number[]) {
      this.empName=name;
      this.empNo=no;
      this.ph=ph;
    }
  }